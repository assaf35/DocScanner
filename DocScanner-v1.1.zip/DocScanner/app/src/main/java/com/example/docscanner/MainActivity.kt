package com.example.docscanner

import android.app.Activity
import android.os.Bundle
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import android.graphics.BitmapFactory
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { DocScannerTheme { DocScannerApp() } }
    }
}

private val scannerOptions = GmsDocumentScannerOptions.Builder()
    .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL) // חיתוך, סיבוב, פילטרים, ניקוי כתמים
    .setGalleryImportAllowed(true)
    .setPageLimit(50)
    .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG, GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
    .build()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocScannerApp() {
    val context = LocalContext.current
    val activity = context as Activity
    val repo = remember { DocumentRepository(context) }
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var docs by remember { mutableStateOf<List<ScannedDoc>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var query by rememberSaveable { mutableStateOf("") }
    var viewing by remember { mutableStateOf<ScannedDoc?>(null) }
    var renaming by remember { mutableStateOf<ScannedDoc?>(null) }
    var deleting by remember { mutableStateOf<ScannedDoc?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun refresh() {
        scope.launch { docs = repo.loadAll(); loading = false }
    }
    LaunchedEffect(Unit) { refresh() }

    val scanner = remember { GmsDocumentScanning.getClient(scannerOptions) }
    val scanLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { res ->
        if (res.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val result = GmsDocumentScanningResult.fromActivityResultIntent(res.data) ?: return@rememberLauncherForActivityResult
        val pageUris = result.pages?.map { it.imageUri }.orEmpty()
        val pdfUri = result.pdf?.uri
        if (pageUris.isEmpty() && pdfUri == null) return@rememberLauncherForActivityResult
        scope.launch {
            runCatching { repo.saveScan(pageUris, pdfUri) }
                .onSuccess { saved ->
                    refresh()
                    val r = snackbar.showSnackbar("המסמך נשמר · ${saved.pageCount} עמודים", actionLabel = "פתיחה")
                    if (r == SnackbarResult.ActionPerformed) viewing = saved
                }
                .onFailure { snackbar.showSnackbar("שמירת המסמך נכשלה. נסו לסרוק שוב.") }
        }
    }

    fun startScan() {
        scanner.getStartScanIntent(activity)
            .addOnSuccessListener { sender -> scanLauncher.launch(IntentSenderRequest.Builder(sender).build()) }
            .addOnFailureListener { e ->
                scope.launch { snackbar.showSnackbar("הסורק לא זמין: ${e.message ?: "בדקו ש-Google Play Services מעודכן"}") }
            }
    }

    fun rotate(doc: ScannedDoc, pages: List<Int>?, degrees: Int) {
        if (busy) return
        busy = true
        scope.launch {
            runCatching { repo.rotate(doc, pages, degrees) }
                .onSuccess { viewing = it; refresh() }
                .onFailure { Toast.makeText(context, "הסיבוב נכשל: ${it.message}", Toast.LENGTH_LONG).show() }
            busy = false
        }
    }

    viewing?.let { doc ->
        PdfViewerScreen(
            doc = doc,
            busy = busy,
            onBack = { if (!busy) viewing = null },
            onShare = { FileActions.share(context, doc) },
            onOpenExternal = { FileActions.openExternal(context, doc) },
            onRotatePage = { i -> rotate(doc, listOf(i), 90) },
            onRotateAll = { deg -> rotate(doc, null, deg) },
        )
        return
    }

    val filtered = remember(docs, query) {
        if (query.isBlank()) docs else docs.filter { it.name.contains(query.trim(), ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            Column(Modifier.background(MaterialTheme.colorScheme.background)) {
                TopAppBar(
                    title = { Text("המסמכים שלי") },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                )
                if (docs.isNotEmpty()) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                        placeholder = { Text("חיפוש לפי שם") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        trailingIcon = {
                            if (query.isNotEmpty()) IconButton(onClick = { query = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "ניקוי חיפוש")
                            }
                        },
                        singleLine = true,
                        shape = MaterialTheme.shapes.extraLarge,
                    )
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = ::startScan,
                icon = { Icon(Icons.Filled.CameraAlt, contentDescription = null) },
                text = { Text("סריקה חדשה") },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                docs.isEmpty() -> EmptyState(Modifier.align(Alignment.Center))
                filtered.isEmpty() -> Text(
                    "לא נמצא מסמך בשם \"$query\"",
                    modifier = Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(150.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(filtered, key = { it.pdf.path }) { doc ->
                        DocCard(
                            doc = doc,
                            onOpen = { viewing = doc },
                            onShare = { FileActions.share(context, doc) },
                            onRename = { renaming = doc },
                            onDelete = { deleting = doc },
                        )
                    }
                }
            }
        }
    }

    renaming?.let { doc ->
        RenameDialog(
            initial = doc.name,
            onDismiss = { renaming = null },
            onConfirm = { newName ->
                scope.launch {
                    if (repo.rename(doc, newName)) { renaming = null; refresh() }
                    else snackbar.showSnackbar("השם ריק או שכבר קיים מסמך בשם הזה")
                }
            },
        )
    }

    deleting?.let { doc ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            icon = { Icon(Icons.Filled.Delete, contentDescription = null) },
            title = { Text("למחוק את המסמך?") },
            text = { Text("\"${doc.name}\" יימחק מהמכשיר ולא ניתן יהיה לשחזר אותו.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { repo.delete(doc); deleting = null; refresh() }
                }) { Text("מחיקה", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("ביטול") } },
        )
    }
}

@Composable
private fun DocCard(
    doc: ScannedDoc,
    onOpen: () -> Unit,
    onShare: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
) {
    val context = LocalContext.current
    var menuOpen by remember { mutableStateOf(false) }
    val date = remember(doc.modified) { SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault()).format(Date(doc.modified)) }

    ElevatedCard(onClick = onOpen) {
        Box {
            Thumbnail(doc.thumbnail, Modifier.fillMaxWidth().aspectRatio(0.78f))
            Text(
                "${doc.pageCount}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .background(MaterialTheme.colorScheme.primary, MaterialTheme.shapes.small)
                    .padding(horizontal = 7.dp, vertical = 2.dp),
            )
        }
        Row(
            Modifier.padding(start = 12.dp, end = 0.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(doc.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "$date  ${Formatter.formatShortFileSize(context, doc.sizeBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "אפשרויות")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("שיתוף") },
                        leadingIcon = { Icon(Icons.Filled.Share, null) },
                        onClick = { menuOpen = false; onShare() },
                    )
                    DropdownMenuItem(
                        text = { Text("שינוי שם") },
                        leadingIcon = { Icon(Icons.Filled.Edit, null) },
                        onClick = { menuOpen = false; onRename() },
                    )
                    DropdownMenuItem(
                        text = { Text("מחיקה") },
                        leadingIcon = { Icon(Icons.Filled.Delete, null) },
                        onClick = { menuOpen = false; onDelete() },
                    )
                }
            }
        }
    }
}

@Composable
private fun Thumbnail(file: File?, modifier: Modifier) {
    val bitmap by produceState<ImageBitmap?>(null, file?.path, file?.lastModified()) {
        value = file?.let { withContext(Dispatchers.IO) { BitmapFactory.decodeFile(it.path)?.asImageBitmap() } }
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        val bmp = bitmap
        if (bmp != null) {
            Image(bmp, contentDescription = null, modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
        } else {
            Icon(Icons.Outlined.Description, contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(40.dp))
        }
    }
}

@Composable
private fun EmptyState(modifier: Modifier) {
    Column(modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Filled.DocumentScanner, contentDescription = null,
            tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(72.dp))
        Spacer(Modifier.height(16.dp))
        Text("עדיין אין מסמכים", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "לחצו על \"סריקה חדשה\" כדי לצלם מסמך, קבלה או תעודה. אפשר גם לייבא תמונות מהגלריה.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun RenameDialog(initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("שינוי שם") },
        text = {
            OutlinedTextField(value = text, onValueChange = { text = it },
                singleLine = true, label = { Text("שם המסמך") })
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text("שמירה") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ביטול") } },
    )
}
