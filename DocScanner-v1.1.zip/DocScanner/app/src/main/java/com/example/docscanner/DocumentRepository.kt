package com.example.docscanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ScannedDoc(
    val pdf: File,
    val thumbnail: File?,
    val pageCount: Int,
    /** משתנה בכל טעינה, כדי שהתצוגה תתרענן אחרי סיבוב. */
    val revision: Long = System.nanoTime(),
) {
    val name: String get() = pdf.nameWithoutExtension
    val modified: Long get() = pdf.lastModified()
    val sizeBytes: Long get() = pdf.length()
}

/**
 * כל מסמך נשמר כ-PDF, ולצידו תיקייה מוסתרת עם עמודי ה-JPEG שלו.
 * סיבוב עמוד = סיבוב ה-JPEG ובנייה מחדש של ה-PDF.
 */
class DocumentRepository(context: Context) {
    private val appContext = context.applicationContext
    private val dir = File(appContext.filesDir, "documents").apply { mkdirs() }

    suspend fun loadAll(): List<ScannedDoc> = withContext(Dispatchers.IO) {
        dir.listFiles { f -> f.isFile && f.extension.equals("pdf", ignoreCase = true) && !f.name.startsWith(".") }
            .orEmpty()
            .map { pdf ->
                val thumb = thumbFor(pdf)
                if (!thumb.exists()) writeThumbnail(pdf, thumb)
                ScannedDoc(pdf, thumb.takeIf(File::exists), countPages(pdf))
            }
            .sortedByDescending { it.modified }
    }

    /** שומר סריקה חדשה. עדיף מתמונות העמודים (מתקן כיוון לפי EXIF); אם אין, מעתיק את ה-PDF של הסורק. */
    suspend fun saveScan(pageUris: List<Uri>, pdfUri: Uri?): ScannedDoc = withContext(Dispatchers.IO) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH-mm-ss", Locale.US).format(Date())
        val pdf = uniqueFile("סריקה $stamp")
        if (pageUris.isNotEmpty()) {
            val pages = pagesDir(pdf).apply { deleteRecursively(); mkdirs() }
            pageUris.forEachIndexed { i, uri ->
                val bmp = decodeUpright(uri) ?: error("לא ניתן לקרוא את עמוד ${i + 1}")
                writeJpeg(bmp, pageFile(pages, i))
                bmp.recycle()
            }
            JpegPdfWriter.write(pageFiles(pages), pdf)
        } else {
            val src = requireNotNull(pdfUri) { "הסורק לא החזיר קובץ" }
            appContext.contentResolver.openInputStream(src)!!.use { input ->
                pdf.outputStream().use { input.copyTo(it) }
            }
        }
        finish(pdf)
    }

    /** מסובב עמודים (null = כל העמודים) בכיוון השעון, במעלות. */
    suspend fun rotate(doc: ScannedDoc, pageIndexes: List<Int>?, degrees: Int): ScannedDoc =
        withContext(Dispatchers.IO) {
            val files = pageFiles(ensurePages(doc.pdf))
            val targets = pageIndexes ?: files.indices.toList()
            for (i in targets) {
                val f = files.getOrNull(i) ?: continue
                val src = BitmapFactory.decodeFile(f.path) ?: continue
                val rotated = rotateBitmap(src, degrees)
                writeJpeg(rotated, f)
                if (rotated !== src) rotated.recycle()
                src.recycle()
            }
            // כותבים לקובץ זמני ומחליפים, כדי לא לשבור את התצוגה הפתוחה
            val tmp = File(dir, ".tmp_${System.nanoTime()}.pdf")
            JpegPdfWriter.write(files, tmp)
            if (!tmp.renameTo(doc.pdf)) {
                tmp.copyTo(doc.pdf, overwrite = true)
                tmp.delete()
            }
            finish(doc.pdf)
        }

    /** מחזיר false אם השם ריק או תפוס. */
    suspend fun rename(doc: ScannedDoc, newName: String): Boolean = withContext(Dispatchers.IO) {
        val clean = newName.replace(Regex("[\\\\/:*?\"<>|]"), "").trim().trimStart('.')
        if (clean.isEmpty()) return@withContext false
        val target = File(dir, "$clean.pdf")
        if (target == doc.pdf) return@withContext true
        if (target.exists()) return@withContext false
        val oldThumb = thumbFor(doc.pdf)
        val oldPages = pagesDir(doc.pdf)
        val ok = doc.pdf.renameTo(target)
        if (ok) {
            if (oldThumb.exists()) oldThumb.renameTo(thumbFor(target))
            if (oldPages.exists()) oldPages.renameTo(pagesDir(target))
        }
        ok
    }

    suspend fun delete(doc: ScannedDoc) = withContext(Dispatchers.IO) {
        doc.pdf.delete()
        thumbFor(doc.pdf).delete()
        pagesDir(doc.pdf).deleteRecursively()
    }

    // ---------- עזר ----------

    private fun finish(pdf: File): ScannedDoc {
        val thumb = thumbFor(pdf)
        thumb.delete()
        writeThumbnail(pdf, thumb)
        return ScannedDoc(pdf, thumb.takeIf(File::exists), countPages(pdf))
    }

    private fun thumbFor(pdf: File) = File(dir, ".thumb_${pdf.nameWithoutExtension}.jpg")
    private fun pagesDir(pdf: File) = File(dir, ".pages_${pdf.nameWithoutExtension}")
    private fun pageFile(pages: File, i: Int) = File(pages, String.format(Locale.US, "%03d.jpg", i + 1))
    private fun pageFiles(pages: File): List<File> =
        pages.listFiles { f -> f.extension == "jpg" }.orEmpty().sortedBy { it.name }

    /** למסמכים ישנים בלי תיקיית עמודים: מרנדר את ה-PDF לתמונות. */
    private fun ensurePages(pdf: File): File {
        val pages = pagesDir(pdf)
        val count = countPages(pdf)
        if (count > 0 && pageFiles(pages).size == count) return pages
        pages.deleteRecursively()
        pages.mkdirs()
        ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            val renderer = PdfRenderer(pfd)
            try {
                for (i in 0 until renderer.pageCount) {
                    val page = renderer.openPage(i)
                    try {
                        val w = 1654 // כ-200 DPI ב-A4
                        val h = (w.toFloat() / page.width * page.height).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        writeJpeg(bmp, pageFile(pages, i))
                        bmp.recycle()
                    } finally { page.close() }
                }
            } finally { renderer.close() }
        }
        return pages
    }

    /** קורא תמונה ומיישר אותה לפי נתוני ה-EXIF (כאן מתוקן הבאג של מכשירים כמו שיאומי). */
    private fun decodeUpright(uri: Uri): Bitmap? {
        val cr = appContext.contentResolver
        val orientation = runCatching {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
        }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 3200) sample *= 2

        val bmp = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null

        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90, ExifInterface.ORIENTATION_TRANSPOSE -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270, ExifInterface.ORIENTATION_TRANSVERSE -> 270
            else -> 0
        }
        val upright = rotateBitmap(bmp, degrees)
        if (upright !== bmp) bmp.recycle()
        return upright
    }

    private fun rotateBitmap(src: Bitmap, degrees: Int): Bitmap {
        val d = ((degrees % 360) + 360) % 360
        if (d == 0) return src
        val m = Matrix().apply { postRotate(d.toFloat()) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun writeJpeg(bmp: Bitmap, out: File) {
        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
    }

    private fun uniqueFile(base: String): File {
        var f = File(dir, "$base.pdf")
        var i = 2
        while (f.exists()) f = File(dir, "$base ($i).pdf").also { i++ }
        return f
    }

    private fun countPages(pdf: File): Int = runCatching {
        ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            val renderer = PdfRenderer(pfd)
            try { renderer.pageCount } finally { renderer.close() }
        }
    }.getOrDefault(0)

    private fun writeThumbnail(pdf: File, out: File) {
        runCatching {
            ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                val renderer = PdfRenderer(pfd)
                try {
                    val page = renderer.openPage(0)
                    try {
                        val w = 400
                        val h = (w.toFloat() / page.width * page.height).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                        bmp.recycle()
                    } finally { page.close() }
                } finally { renderer.close() }
            }
        }
    }
}
