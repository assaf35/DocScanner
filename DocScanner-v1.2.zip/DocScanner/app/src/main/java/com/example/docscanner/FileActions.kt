package com.example.docscanner

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider

object FileActions {
    private fun uriFor(ctx: Context, doc: ScannedDoc) =
        FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", doc.pdf)

    fun share(ctx: Context, doc: ScannedDoc) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uriFor(ctx, doc))
            putExtra(Intent.EXTRA_SUBJECT, doc.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "שיתוף מסמך"))
    }

    fun openExternal(ctx: Context, doc: ScannedDoc) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uriFor(ctx, doc), "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            ctx.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "לא נמצאה אפליקציה לפתיחת PDF", Toast.LENGTH_SHORT).show()
        }
    }
}
