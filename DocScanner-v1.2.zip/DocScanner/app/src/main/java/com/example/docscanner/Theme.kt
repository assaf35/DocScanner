package com.example.docscanner

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(
    primary = Color(0xFF0F9D6B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC9F2DD),
    onPrimaryContainer = Color(0xFF00391F),
    background = Color(0xFFF5F7F6),
    surface = Color(0xFFF5F7F6),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF6FD3A8),
    onPrimary = Color(0xFF00391F),
    primaryContainer = Color(0xFF005234),
    onPrimaryContainer = Color(0xFFC9F2DD),
)

@Composable
fun DocScannerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        content = content,
    )
}
