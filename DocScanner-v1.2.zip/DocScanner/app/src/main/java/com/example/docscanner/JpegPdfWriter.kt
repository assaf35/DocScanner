package com.example.docscanner

import android.graphics.BitmapFactory
import java.io.File
import java.util.Locale

/**
 * כותב PDF שבו כל עמוד הוא תמונת JPEG, בלי לדחוס את התמונה מחדש.
 * כך אנחנו שולטים בכיוון של כל עמוד, בלי תלות בסורק.
 */
object JpegPdfWriter {
    private const val PAGE_WIDTH = 595f // רוחב A4 בנקודות PDF

    fun write(jpegs: List<File>, out: File) {
        require(jpegs.isNotEmpty()) { "אין עמודים" }
        val total = 2 + jpegs.size * 3
        val offsets = LongArray(total + 1)
        val latin = Charsets.ISO_8859_1

        out.outputStream().buffered().use { os ->
            var pos = 0L
            fun raw(b: ByteArray) { os.write(b); pos += b.size }
            fun str(s: String) = raw(s.toByteArray(latin))
            fun obj(n: Int) { offsets[n] = pos; str("$n 0 obj\n") }
            fun num(v: Float) = String.format(Locale.US, "%.2f", v)

            str("%PDF-1.4\n")
            raw(byteArrayOf(0x25, 0xE2.toByte(), 0xE3.toByte(), 0xCF.toByte(), 0xD3.toByte(), 0x0A))

            obj(1); str("<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
            val kids = jpegs.indices.joinToString(" ") { "${3 + it * 3} 0 R" }
            obj(2); str("<< /Type /Pages /Kids [ $kids ] /Count ${jpegs.size} >>\nendobj\n")

            jpegs.forEachIndexed { i, file ->
                val pageObj = 3 + i * 3
                val imgObj = pageObj + 1
                val contentObj = pageObj + 2

                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.path, o)
                val w = o.outWidth
                val h = o.outHeight
                require(w > 0 && h > 0) { "עמוד ${i + 1} פגום" }
                val pw = num(PAGE_WIDTH)
                val ph = num(PAGE_WIDTH * h / w)

                obj(pageObj)
                str("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $pw $ph] " +
                    "/Resources << /XObject << /Im0 $imgObj 0 R >> >> /Contents $contentObj 0 R >>\nendobj\n")

                val bytes = file.readBytes()
                obj(imgObj)
                str("<< /Type /XObject /Subtype /Image /Width $w /Height $h /ColorSpace /DeviceRGB " +
                    "/BitsPerComponent 8 /Filter /DCTDecode /Length ${bytes.size} >>\nstream\n")
                raw(bytes)
                str("\nendstream\nendobj\n")

                val content = "q $pw 0 0 $ph 0 0 cm /Im0 Do Q".toByteArray(latin)
                obj(contentObj)
                str("<< /Length ${content.size} >>\nstream\n")
                raw(content)
                str("\nendstream\nendobj\n")
            }

            val xref = pos
            str("xref\n0 ${total + 1}\n0000000000 65535 f \n")
            for (n in 1..total) str(String.format(Locale.US, "%010d 00000 n \n", offsets[n]))
            str("trailer\n<< /Size ${total + 1} /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n")
        }
    }
}
