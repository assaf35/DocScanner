package com.example.docscanner

import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Rotate90DegreesCw
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/** עוטף את PdfRenderer (שאינו thread-safe) כך שרק עמוד אחד מרונדר בכל פעם. */
class PdfDocRenderer(file: File) {
    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val mutex = Mutex()
    private var closed = false
    val pageCount: Int = renderer.pageCount

    suspend fun render(index: Int, widthPx: Int): Bitmap? = mutex.withLock {
        if (closed) return@withLock null
        withContext(Dispatchers.IO) {
            val page = renderer.openPage(index)
            try {
                val h = (widthPx.toFloat() / page.width * page.height).toInt().coerceAtLeast(1)
                Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888).apply {
                    eraseColor(AColor.WHITE)
                    page.render(this, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                }
            } finally { page.close() }
        }
    }

    fun close() = runBlocking {
        mutex.withLock {
            if (!closed) { closed = true; renderer.close(); pfd.close() }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerScreen(
    doc: ScannedDoc,
    busy: Boolean,
    onBack: () -> Unit,
    onShare: () -> Unit,
    onOpenExternal: () -> Unit,
    onRotatePage: (Int) -> Unit,
    onRotateAll: (Int) -> Unit,
) {
    BackHandler(onBack = onBack)
    var menuOpen by remember { mutableStateOf(false) }
    val renderer = remember(doc) { runCatching { PdfDocRenderer(doc.pdf) }.getOrNull() }
    DisposableEffect(renderer) { onDispose { renderer?.close() } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(doc.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${renderer?.pageCount ?: 0} עמודים",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "חזרה")
                    }
                },
                actions = {
                    IconButton(onClick = onShare) { Icon(Icons.Filled.Share, contentDescription = "שיתוף") }
                    IconButton(onClick = onOpenExternal) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "פתיחה באפליקציה אחרת")
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }, enabled = !busy) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "אפשרויות")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("סיבוב כל העמודים 180°") },
                                onClick = { menuOpen = false; onRotateAll(180) },
                            )
                            DropdownMenuItem(
                                text = { Text("סיבוב כל העמודים 90° ימינה") },
                                onClick = { menuOpen = false; onRotateAll(90) },
                            )
                            DropdownMenuItem(
                                text = { Text("סיבוב כל העמודים 90° שמאלה") },
                                onClick = { menuOpen = false; onRotateAll(270) },
                            )
                        }
                    }
                },
            )
        },
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
    ) { padding ->
        if (renderer == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("הקובץ פגום ולא ניתן לפתוח אותו")
            }
        } else {
            Box(Modifier.fillMaxSize().padding(padding)) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(renderer.pageCount) { i ->
                        PdfPageView(renderer, i, rotateEnabled = !busy, onRotate = { onRotatePage(i) })
                    }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
            }
        }
    }
}

@Composable
private fun PdfPageView(renderer: PdfDocRenderer, index: Int, rotateEnabled: Boolean, onRotate: () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val widthPx = with(LocalDensity.current) { maxWidth.roundToPx() }.coerceIn(1, 1400)
        val page by produceState<ImageBitmap?>(null, index, widthPx) {
            value = renderer.render(index, widthPx)?.asImageBitmap()
        }
        Surface(color = Color.White, shadowElevation = 2.dp) {
            Box {
                val bmp = page
                if (bmp != null) {
                    Image(
                        bitmap = bmp,
                        contentDescription = "עמוד ${index + 1}",
                        modifier = Modifier.fillMaxWidth(),
                        contentScale = ContentScale.FillWidth,
                    )
                } else {
                    Box(Modifier.fillMaxWidth().aspectRatio(0.707f), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                Text(
                    "${index + 1}/${renderer.pageCount}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(8.dp)
                        .background(Color(0x99000000), MaterialTheme.shapes.small)
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                )
                FilledTonalIconButton(
                    onClick = onRotate,
                    enabled = rotateEnabled,
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp),
                ) {
                    Icon(Icons.Filled.Rotate90DegreesCw, contentDescription = "סיבוב עמוד ${index + 1}")
                }
            }
        }
    }
}
