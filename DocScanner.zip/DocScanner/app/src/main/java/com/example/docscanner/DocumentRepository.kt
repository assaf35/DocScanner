package com.example.docscanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ScannedDoc(
    val pdf: File,
    val thumbnail: File?,
    val pageCount: Int,
) {
    val name: String get() = pdf.nameWithoutExtension
    val modified: Long get() = pdf.lastModified()
    val sizeBytes: Long get() = pdf.length()
}

/** שומר את המסמכים הסרוקים כקובצי PDF בתיקייה הפרטית של האפליקציה. */
class DocumentRepository(context: Context) {
    private val appContext = context.applicationContext
    private val dir = File(appContext.filesDir, "documents").apply { mkdirs() }

    suspend fun loadAll(): List<ScannedDoc> = withContext(Dispatchers.IO) {
        dir.listFiles { f -> f.extension.equals("pdf", ignoreCase = true) }
            .orEmpty()
            .map { pdf ->
                val thumb = thumbFor(pdf)
                if (!thumb.exists()) writeThumbnail(pdf, thumb)
                ScannedDoc(pdf, thumb.takeIf(File::exists), countPages(pdf))
            }
            .sortedByDescending { it.modified }
    }

    suspend fun saveScan(pdfUri: Uri): ScannedDoc = withContext(Dispatchers.IO) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH-mm-ss", Locale.US).format(Date())
        val pdf = uniqueFile("סריקה $stamp")
        appContext.contentResolver.openInputStream(pdfUri)!!.use { input ->
            pdf.outputStream().use { input.copyTo(it) }
        }
        val thumb = thumbFor(pdf)
        writeThumbnail(pdf, thumb)
        ScannedDoc(pdf, thumb.takeIf(File::exists), countPages(pdf))
    }

    /** מחזיר false אם השם ריק או תפוס. */
    suspend fun rename(doc: ScannedDoc, newName: String): Boolean = withContext(Dispatchers.IO) {
        val clean = newName.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
        if (clean.isEmpty()) return@withContext false
        val target = File(dir, "$clean.pdf")
        if (target == doc.pdf) return@withContext true
        if (target.exists()) return@withContext false
        val oldThumb = thumbFor(doc.pdf)
        val ok = doc.pdf.renameTo(target)
        if (ok && oldThumb.exists()) oldThumb.renameTo(thumbFor(target))
        ok
    }

    suspend fun delete(doc: ScannedDoc) = withContext(Dispatchers.IO) {
        doc.pdf.delete()
        thumbFor(doc.pdf).delete()
    }

    private fun thumbFor(pdf: File) = File(dir, ".thumb_${pdf.nameWithoutExtension}.jpg")

    private fun uniqueFile(base: String): File {
        var f = File(dir, "$base.pdf")
        var i = 2
        while (f.exists()) f = File(dir, "$base ($i).pdf").also { i++ }
        return f
    }

    private fun countPages(pdf: File): Int = runCatching {
        ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            val renderer = PdfRenderer(pfd)
            try { renderer.pageCount } finally { renderer.close() }
        }
    }.getOrDefault(0)

    private fun writeThumbnail(pdf: File, out: File) {
        runCatching {
            ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                val renderer = PdfRenderer(pfd)
                try {
                    val page = renderer.openPage(0)
                    try {
                        val w = 400
                        val h = (w.toFloat() / page.width * page.height).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                        bmp.recycle()
                    } finally { page.close() }
                } finally { renderer.close() }
            }
        }
    }
}
